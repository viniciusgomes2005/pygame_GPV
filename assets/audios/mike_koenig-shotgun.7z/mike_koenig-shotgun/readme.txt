Got these under CC-BY 3.0 from http://soundbible.com/tags-game.html
